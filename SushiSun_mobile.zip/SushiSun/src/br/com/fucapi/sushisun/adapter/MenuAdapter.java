package br.com.fucapi.sushisun.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sushisun.R;

public class MenuAdapter extends BaseAdapter {
	
	private int[] title;
	private int[] images;
	private Context ctx;
	private LayoutInflater inflater;

	public MenuAdapter(Context ctx,int[] images,int[] title){
		this.ctx=ctx;
		this.images=images;
		this.title=title;
	}

	@Override
	public int getCount() {
		
		return images.length;
	}

	@Override
	public Object getItem(int position) {

		return images[position];
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View view = inflater.inflate(R.layout.item_menu_view, null);
		
		ImageView imageView = (ImageView) view.findViewById(R.id.img_menu_item);
		Bitmap bitmapImage = BitmapFactory.decodeResource(ctx.getResources(), images[position]);
		Bitmap imagemRedimensionada = Bitmap.createScaledBitmap(bitmapImage, 200, 200, true);
		imageView.setImageBitmap(imagemRedimensionada);
		imageView.setAdjustViewBounds(true);
		
		final TextView title = (TextView) view.findViewById(R.id.text_menu_item);
		title.setText(this.title[position]);
		
		return view;
	}

}
