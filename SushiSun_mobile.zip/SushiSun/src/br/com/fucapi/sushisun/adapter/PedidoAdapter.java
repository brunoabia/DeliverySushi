package br.com.fucapi.sushisun.adapter;

import java.util.List;

import com.example.sushisun.R;

import br.com.fucapi.sushisun.model.Produto;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class PedidoAdapter extends BaseAdapter {
	
	private List<Produto> pedido;
	private Context ctx;
	private LayoutInflater inflater;

	public PedidoAdapter(Context ctx,List<Produto> pedido){
		this.ctx = ctx;
		this.pedido = pedido;
	}

	@Override
	public int getCount() {
		
		return pedido.size();
	}

	@Override
	public Object getItem(int position) {
		
		return pedido.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View view = inflater.inflate(R.layout.item_menu_view, null);
		
		//ImageView imageView = (ImageView) view.findViewById(R.id.imagem_item);
		//Bitmap bitmapImage = BitmapFactory.decodeResource(ctx.getResources(), images[position]);
		//Bitmap imagemRedimensionada = Bitmap.createScaledBitmap(bitmapImage, 150, 150, true);
		//imageView.setImageBitmap(imagemRedimensionada);
		//imageView.setAdjustViewBounds(true);
		
		TextView nomePrato = (TextView) view.findViewById(R.id.prato_nome);
		nomePrato.setText(pedido.get(position).getNome());
		
		TextView qtd = (TextView) view.findViewById(R.id.qtd_valor);
		qtd.setText(pedido.get(position).getQuantidade());
		
		return null;
	}

}
