package br.com.fucapi.sushisun.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;
import br.com.fucapi.sushisun.model.Produto;

import com.example.sushisun.R;

public class ResumoPedidoAdapter extends BaseAdapter {
	
	private Context context;
	private List<Produto> itens;
	
	public ResumoPedidoAdapter(Context context,List<Produto> itens){
		this.context=context;
		this.itens=itens;
	}

	@Override
	public int getCount() {
		
		return itens.size();
	}

	@Override
	public Object getItem(int arg0) {
		
		return itens.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		
		return arg0;
	}

	@Override
	public View getView(int position, View arg1, ViewGroup arg2) {
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View view = inflater.inflate(R.layout.item_cardapio, null);
		
		TextView nomeItem = (TextView) view.findViewById(R.id.nome_item);
		nomeItem.setText(itens.get(position).getNome());
		
		TextView precoItem = (TextView) view.findViewById(R.id.item_preco);
		precoItem.setText(itens.get(position).getPreco());
		
		TextView excluir = (TextView) view.findViewById(R.id.pedir_item);
		excluir.setText("Click para excluir este item.");
		
		EditText edit = (EditText) view.findViewById(R.id.valor_item_qtd);
		edit.setVisibility(View.INVISIBLE);
		
		return view;
	}

}
