package br.com.fucapi.sushisun.adapter;

import java.util.List;

import com.example.sushisun.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import br.com.fucapi.sushisun.model.Produto;

public class CardapioAdapter extends BaseAdapter {
	
	private Context context;
	private List<Produto> itens;

	public CardapioAdapter(Context context,List<Produto> itens){
		this.context = context;
		this.itens=itens;
	}

	@Override
	public int getCount() {
		
		return itens.size();
	}

	@Override
	public Object getItem(int arg0) {
		
		return itens.get(arg0);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View view = inflater.inflate(R.layout.item_cardapio, null);
		
		TextView nomeItem = (TextView) view.findViewById(R.id.nome_item);
		nomeItem.setText(itens.get(position).getNome());
		
		TextView precoItem = (TextView) view.findViewById(R.id.item_preco);
		precoItem.setText(itens.get(position).getPreco());
		
		return view;
	}

}
