package br.com.fucapi.sushisun.model;

public class Mesa {
	private long id;
	private int quantidade;
	private int lugares;
	private boolean estaReservado;

	public Mesa(int quantidade, int lugares, boolean estaReservado){
		this.quantidade = quantidade;
		this.lugares = lugares;
		this.estaReservado = estaReservado;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public int getLugares() {
		return lugares;
	}

	public void setLugares(int lugares) {
		this.lugares = lugares;
	}

	public boolean isEstaReservado() {
		return estaReservado;
	}

	public void setEstaReservado(boolean estaReservado) {
		this.estaReservado = estaReservado;
	}

}
