package br.com.fucapi.sushisun.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;
import br.com.fucapi.sushisun.JSON.JSONConverter;
import br.com.fucapi.sushisun.activity.MainScreenActivity;
import br.com.fucapi.sushisun.webClient.WebClient;

public class ReservationTask extends AsyncTask<String, Double, Boolean> {

	private Context context;
	private ProgressDialog dialog;

	public ReservationTask(Context context){
		this.context = context;
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		
		dialog = new ProgressDialog(context);
		dialog.setTitle("Solicitanto Reserva,aguarde...");
		dialog.show();
	}
	
	@Override
	protected Boolean doInBackground(String... arg) {
		String dadosJSON;
		String respostaJSON;
		String name = arg[0];
		Integer places = Integer.parseInt(arg[1]);
		JSONConverter converter = new JSONConverter();
		dadosJSON = converter.convertReservationToJSON(name, places);
		
		WebClient client = new WebClient();
		respostaJSON = client.post(dadosJSON);
		
		return converter.convertFromJSON(dadosJSON);
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		super.onPostExecute(result);
		
		if(result){
			Intent it = new Intent(context,MainScreenActivity.class);
			dialog.dismiss();
			context.startActivity(it);
			Toast.makeText(context, "Reserva confirmada!", Toast.LENGTH_LONG).show();
		}else{
			dialog.dismiss();
			Toast.makeText(context, "Não foi possível realizar a reserva!", Toast.LENGTH_LONG).show();
		}
	}

}
