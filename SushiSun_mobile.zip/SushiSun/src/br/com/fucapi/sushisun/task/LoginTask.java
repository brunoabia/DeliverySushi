package br.com.fucapi.sushisun.task;

import br.com.fucapi.sushisun.JSON.JSONConverter;
import br.com.fucapi.sushisun.activity.MainScreenActivity;
import br.com.fucapi.sushisun.webClient.WebClient;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

public class LoginTask extends AsyncTask<String, Double, Boolean> {
	
	private Context context;
	private ProgressDialog dialog;

	public LoginTask(Context context){
		this.context = context;
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		
		dialog = new ProgressDialog(context);
		dialog.setTitle("Efetuando autenticação, por favor aguarde!");
		dialog.show();
	}

	@Override
	protected Boolean doInBackground(String... arg) {
	/*	String dadosJSON;
		String respostaJSON;
		String nome = arg[0];
		String password = arg[1];
		
		JSONConverter converter = new JSONConverter();
		dadosJSON = converter.convertLoginToJSON(nome, password);
		
		WebClient client = new WebClient();
		respostaJSON = client.post(dadosJSON);
		
		return converter.convertFromJSON(respostaJSON);*/
		
		try {
		    Thread.sleep(5000);
		} catch (InterruptedException e) {
		    e.printStackTrace();
		}
		
		return true;
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		super.onPostExecute(result);
		
		if(result){
			Intent it = new Intent(context,MainScreenActivity.class);
			dialog.dismiss();
			context.startActivity(it);
		}else{
			dialog.dismiss();
			Toast.makeText(context, "Login ou senha inválidos! Tente novamente.", Toast.LENGTH_SHORT).show();
		}
	}

}
