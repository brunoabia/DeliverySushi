package br.com.fucapi.sushisun.task;

import java.util.List;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import br.com.fucapi.sushisun.JSON.JSONConverter;
import br.com.fucapi.sushisun.model.Produto;
import br.com.fucapi.sushisun.webClient.WebClient;

public class PedidoTask extends AsyncTask<List<Produto>, Double, Boolean> {
	
	private Context context;
	private ProgressDialog dialog;

	public PedidoTask(Context context){
		this.context=context;
	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		
		dialog = new ProgressDialog(context);
		dialog.setTitle("Enviando pedido, por favor aguarde...");
		
		dialog.show();
	}

	@Override
	protected Boolean doInBackground(List<Produto>... params) {
		String dadosJSON;
		String respostaJSON;
		
		List<Produto> pedido=params[0];
		
		JSONConverter converter = new JSONConverter();
		dadosJSON = converter.convertPedidoToJSON(pedido);
		
		WebClient client = new WebClient();
		respostaJSON = client.post(dadosJSON);
		
		return converter.convertFromJSON(respostaJSON);
	}
	
	@Override
	protected void onPostExecute(Boolean result) {
		super.onPostExecute(result);
		
		if(result){
			dialog.dismiss();
			Toast.makeText(context, "Pedido enviado com sucesso!", Toast.LENGTH_SHORT);
		}else{
			dialog.dismiss();
			Toast.makeText(context, "Erro ao enviar pedido, tente novamente!", Toast.LENGTH_SHORT);
		}
	}

}
