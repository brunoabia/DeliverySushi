package br.com.fucapi.sushisun.util;

import android.content.Context;
import android.graphics.Typeface;

public class Utils {

	private static Typeface robotoRegular;
	private static Typeface robotoBold;

	public static void initFonts(final Context context) {
		robotoRegular = Typeface.createFromAsset(context.getAssets(), "font/Roboto-Regular.ttf");
		robotoBold = Typeface.createFromAsset(context.getAssets(), "font/Roboto-Bold.ttf");
	}

	public static Typeface getRobotoRegular() {
		return robotoRegular;
	}

	public static Typeface getRobotoBold() {
		return robotoBold;
	}
}