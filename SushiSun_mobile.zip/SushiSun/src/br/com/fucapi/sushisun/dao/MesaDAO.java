package br.com.fucapi.sushisun.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class MesaDAO extends DatabaseHelper {

	public MesaDAO(Context context) {
		super(context);
	}
	
	
}
