package br.com.fucapi.sushisun.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
	
	private static final String DATABASE = "SushiSun";
	private static final int VERSAO = 1;
	
	private static final String CREATE_TABLE_USUARIO = "CREATE TABLE Usuario (id INTEGER PRIMARY KEY AUTOINCREMENT,"
												+ "login TEXT NOT NULL, senha TEXT NOT NULL);";
	
	private static final String DROP_TABLE_USUARIO = "DROP TABLE IF EXISTS Usuario";
	
	private static final String CREATE_TABLE_PRODUTO = "CREATE TABLE Produto (id INTEGER PRIMARY KEY AUTOINCREMENT, "
												+ "nome TEXT, quantidade INTEGER, valor REAL);";
	
	private static final String DROP_TABLE_PRODUTO = "DROP TABLE IF EXISTS Produto";
	
	private static final String CREATE_TABLE_RESERVATION = "CREATE TABLE Mesa (id INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ "nome TEXT, quantidade INTEGER, lugares REAL);";
	
	private static final String DROP_TABLE_RESERVATION = "DROP TABLE IF EXISTS Mesa";

	public DatabaseHelper(Context context) {
		super(context, DATABASE, null, VERSAO);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE_USUARIO);
		db.execSQL(CREATE_TABLE_PRODUTO);
		db.execSQL(CREATE_TABLE_RESERVATION);

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		db.execSQL(DROP_TABLE_USUARIO);
		db.execSQL(DROP_TABLE_PRODUTO);
		db.execSQL(DROP_TABLE_RESERVATION);

		this.onCreate(db);
	}

}
