package br.com.fucapi.sushisun.dao;

import br.com.fucapi.sushisun.model.Usuario;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.widget.CalendarView;

public class UsuarioDAO extends DatabaseHelper {

	public UsuarioDAO(Context context) {
		super(context);
	}
	
	public void salvar(Usuario usuario){
		ContentValues values = new ContentValues();
		
		values.put("login", usuario.getLogin());
		values.put("senha", usuario.getSenha());
		
		getWritableDatabase().insert("Usuario", null, values);
	}

}
