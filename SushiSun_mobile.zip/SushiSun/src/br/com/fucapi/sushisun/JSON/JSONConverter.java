package br.com.fucapi.sushisun.JSON;

import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import br.com.fucapi.sushisun.model.Produto;
import br.fucapi.sushisun.log.WrapperLog;

public class JSONConverter {
	
	private static final String RESULT = "autenticacao";

	public String convertLoginToJSON(String nome, String password){
		JSONObject jo = new JSONObject();
		
		try {
			jo.put("nome",nome);
			jo.put("senha",password);
		
			return jo.toString();
		} catch (JSONException e) {
			WrapperLog.error("Erro ao gerar JSON", e);
			return null;
		}
	}
	
	public String convertReservationToJSON(String nome, Integer places){
		JSONObject jo= new JSONObject();
		
		try {
			jo.put("nome",nome);
			jo.put("lugares",places);
		
			return jo.toString();
		} catch (JSONException e) {
			WrapperLog.error("Erro ao gerar JSON", e);
			return null;
		}
	}
	
	public boolean convertFromJSON(String dadosJSON){
		JSONObject jo = new JSONObject();
		try {
			return jo.getBoolean(RESULT);
		} catch (JSONException e) {
			e.printStackTrace();
			return false;
		}
	}

	public String convertPedidoToJSON(List<Produto> pedido) {
		JSONStringer js = new JSONStringer();
		
		try {
			
			js.object().key("pedido").array();
			js.object().key("pratos").array();
			
			for(Produto item:pedido){				
				js.object();
				js.key("nomePrato").value(item.getNome());
				js.key("quantidade").value(item.getQuantidade());
				js.key("preco").value(item.getPreco());
				js.endObject();
			}
			
			js.endArray().endObject();
			js.endArray().endObject();
			
			return js.toString();
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
		
	}
}
