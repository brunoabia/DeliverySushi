package br.com.fucapi.sushisun.singleton;

import java.util.ArrayList;
import java.util.List;

import br.com.fucapi.sushisun.model.Produto;

public class Singleton {
	
	private static Singleton instance; 
	
	private List<Produto> listaPedido = new ArrayList<Produto>();
	
	private Singleton(){}

	public List<Produto> getListaPedido() {
		return listaPedido;
	}

	public void setListaPedido(List<Produto> listaPedido) {
		this.listaPedido = listaPedido;
	}

	public static synchronized Singleton getInstance() {
		if(instance==null){
			instance = new Singleton();
		}
		return instance;
	}
}
