package br.com.fucapi.sushisun.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import br.com.fucapi.sushisun.adapter.MenuAdapter;

import com.example.sushisun.R;

public class MenuActivity extends Activity implements OnItemClickListener {
	
	int[] images = {R.drawable.temaki,R.drawable.sushi,R.drawable.niguiri,
					R.drawable.pratos,R.drawable.sobremesa};
	
	int[] title = {R.string.temaki,R.string.sushi,R.string.niguiri,
					  R.string.dishes,R.string.dessert};
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.menu_view);
		
		final ListView listView = (ListView) findViewById(R.id.listview_menu);
		MenuAdapter adapter = new MenuAdapter(this,images,title);
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(this);
	}


	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		
		switch(position){
		
		case 0:
			break;
		case 1:
			startActivity(new Intent(this,SushiCardapioActivity.class));
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		default:
			break;
		}
		
	}
	
}
