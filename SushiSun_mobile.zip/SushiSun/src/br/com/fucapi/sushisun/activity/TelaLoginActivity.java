package br.com.fucapi.sushisun.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import br.com.fucapi.sushisun.task.LoginTask;

import com.example.sushisun.R;

public class TelaLoginActivity extends Activity implements OnClickListener {
	
	private EditText edPassword;
	private EditText edLogin;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.login_view);
		
		Button login = (Button) findViewById(R.id.button_enter);
		login.setOnClickListener(this);
		
		Button cancel = (Button) findViewById(R.id.button_cancel);
		cancel.setOnClickListener(this);
		
		edLogin = (EditText) findViewById(R.id.editText_login);
		edPassword = (EditText) findViewById(R.id.editText_password);

	}
	

	@Override
	public void onClick(View view) {
		
		int id = view.getId();
		
		switch(id){
		
		case R.id.button_enter:
			Log.i("SUSHISUN", "Logar");
			LoginTask loginTask = new LoginTask(this);
			loginTask.execute(edLogin.getText().toString(),edPassword.getText().toString());
			
			break;
			
		case R.id.button_cancel:
			edLogin.setText("");
			edPassword.setText("");
			finish();
			break;
		}
	}
}
