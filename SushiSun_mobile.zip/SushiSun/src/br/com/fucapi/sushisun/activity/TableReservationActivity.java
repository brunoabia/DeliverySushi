package br.com.fucapi.sushisun.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import br.com.fucapi.sushisun.task.ReservationTask;

import com.example.sushisun.R;

public class TableReservationActivity extends Activity implements OnClickListener {
	
	private EditText nameReservation;
	private EditText placesReservation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.table_reservation_screen);
		
		nameReservation = (EditText) findViewById(R.id.eTName_reservation);
		placesReservation = (EditText) findViewById(R.id.eTPlaces_reservation);
		
		final Button send = (Button) findViewById(R.id.button_send);
		
		send.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		
		ReservationTask reservasionTask = new ReservationTask(this);
		reservasionTask.execute(nameReservation.getText().toString(),placesReservation.getText().toString());
	}

}
