package br.com.fucapi.sushisun.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.example.sushisun.R;

public class MainScreenActivity extends Activity implements OnClickListener {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_screen_view);
		
		Button btMenu = (Button) findViewById(R.id.button_menu);
		btMenu.setOnClickListener(this);
		
		Button btReservation = (Button) findViewById(R.id.button_reservation);
		btReservation.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		
		int id = view.getId();
		
		switch(id){
		
		case R.id.button_menu:
			startActivity(new Intent(this,MenuActivity.class));
			break;
		case R.id.button_reservation:
			Log.i("SUSHISUN", "Reservation");
			startActivity(new Intent(this,TableReservationActivity.class));
			break;
		}
		
	}
	

}
