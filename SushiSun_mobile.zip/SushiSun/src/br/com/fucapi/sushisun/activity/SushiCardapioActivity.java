package br.com.fucapi.sushisun.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import br.com.fucapi.sushisun.adapter.CardapioAdapter;
import br.com.fucapi.sushisun.model.Produto;
import br.com.fucapi.sushisun.singleton.Singleton;

import com.example.sushisun.R;

public class SushiCardapioActivity extends Activity implements OnItemClickListener {
	
	
	private List<Produto> listaDeProdutos;
	private int totalPedido = 0;
	private TextView total;
	private Singleton singleton = Singleton.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.sushi_cardapio_view);
		
		ListView listView = (ListView) findViewById(R.id.cardapio_listView);
		
		listaDeProdutos = criarProdutosSushi();
		
		CardapioAdapter adapter = new CardapioAdapter(this,listaDeProdutos);
		listView.setAdapter(adapter);
		listView.setOnItemClickListener(this);
		
		//Button botaoContinuar = (Button) findViewById(R.id.continuar_pedido);
	//	botaoContinuar.setOnClickListener(this);
		
		//total = (TextView) findViewById(R.id.total_valor);
		//total.setText("R$ "+totalPedido);
		
	}
	
	private List<Produto> criarProdutosSushi(){
		
		final String[] nomePrato = {"Filadelphia", "Hot Filadelphia", "Butterfly","Hot Butterfly"};
		final String[] preco = {"14,00","16,00","14,00","16,00"};
		
		ArrayList<Produto> produtos = new ArrayList<Produto>();
		
		for(int i=0;i<nomePrato.length;i++){
			Produto produto = new Produto();
			produto.setNome(nomePrato[i]);
			produto.setPreco(preco[i]);
			produtos.add(produto);
		}
		
		return produtos;
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		
		Produto p = new Produto();
		p.setNome(listaDeProdutos.get(position).getNome());
		p.setPreco(listaDeProdutos.get(position).getPreco());
		p.setQuantidade(listaDeProdutos.get(position).getQuantidade());
		
		singleton.getListaPedido().add(p);
		atualizaTotal();
	}
/*
	@Override
	public void onClick(View v) {
		int id = v.getId();
		
		switch(id){
		
		case R.id.continuar_pedido:
			startActivity(new Intent(this,ResumoPedidoActivity.class));
			break;
			
		default:
			break;
		}
	}
	*/
	private void atualizaTotal(){
		float preco;
		int quantidade;
		
		for(int i=0;i<singleton.getListaPedido().size();i++){
			preco = Float.parseFloat(singleton.getListaPedido().get(i).getPreco());
			quantidade = singleton.getListaPedido().get(i).getQuantidade();
			totalPedido+=(preco*quantidade);
		}
		total.setText("R$ "+totalPedido);
	}

}
