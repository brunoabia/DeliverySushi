package br.com.fucapi.sushisun.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import br.com.fucapi.sushisun.adapter.PedidoAdapter;
import br.com.fucapi.sushisun.adapter.ResumoPedidoAdapter;
import br.com.fucapi.sushisun.singleton.Singleton;
import br.com.fucapi.sushisun.task.PedidoTask;

import com.example.sushisun.R;

public class ResumoPedidoActivity extends Activity implements OnClickListener, OnItemClickListener {
	
	private Singleton singleton = Singleton.getInstance();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.pedido_detalhe);
		
		ResumoPedidoAdapter adapter = new ResumoPedidoAdapter(this,singleton.getListaPedido());
			
		ListView listView = (ListView) findViewById(R.id.listview_menu);
		listView.setAdapter(adapter);
		listView.setOnItemClickListener(this);
		
		Button enviarPedido = (Button) findViewById(R.id.bt_enviar);
		enviarPedido.setOnClickListener(this);
		
		Button cancelarPedido = (Button) findViewById(R.id.bt_cancelar);
		cancelarPedido.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
				
		switch(id){
		
		case R.id.bt_enviar:
			PedidoTask pedidoTask = new PedidoTask(this);
			pedidoTask.execute(singleton.getListaPedido());
			break;
			
		case R.id.bt_cancelar:
			
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		
		singleton.getListaPedido().remove(position);
		Toast.makeText(this, "Item removido com sucesso!!", Toast.LENGTH_SHORT).show();
	}

}
