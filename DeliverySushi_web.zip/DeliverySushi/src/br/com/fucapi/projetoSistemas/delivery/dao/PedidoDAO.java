package br.com.fucapi.projetoSistemas.delivery.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hamcrest.core.IsNot;
import org.hamcrest.core.IsNull;

import br.com.fucapi.projetoSistemas.delivery.bean.Pedido;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusPedidoEnum;

public class PedidoDAO {
	
	private EntityManager entityManager;

	public PedidoDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void cadastrar(Pedido pedido){
		
		entityManager.persist(pedido);
	}
	
	public void alterar(Pedido pedido){
		entityManager.merge(pedido);
	}
	
	public void excluir(Pedido pedido){
		entityManager.remove(pedido);		
	}


	public List<Pedido> listar(StatusPedidoEnum statusPedido, int numMesa){
		System.out.println(Integer.parseInt(statusPedido.getKey().toString()));
		String sql = "Select pedido from Pedido pedido ";
		
		
			if(numMesa != 0){	
				sql = sql + " where  pedido.numMesa = :numMesa and  pedido.statusPedido = :statusPedido";
			}else{
				sql = sql + " where  pedido.statusPedido = :statusPedido";
			}
				
		
		Query query= entityManager.createQuery(sql,Pedido.class);
		
		query.setParameter("statusPedido", statusPedido);
		if(numMesa != 0){	
			query.setParameter("numMesa", numMesa);
		}
		return query.getResultList();
	}
}
