package br.com.fucapi.projetoSistemas.delivery.dao.teste;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;

import junit.framework.Assert;

import org.junit.Test;

import br.com.fucapi.projetoSistemas.delivery.bean.Pedido;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusPedidoEnum;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.PedidoDAO;

public class PedidoDAOTest {

	@Test
	public void testPedidoDAO() {
		fail("Not yet implemented");
	}

	@Test
	public void testCadastrar() {
		EntityManager entityManager = JPAUtil.getEntityManager();
		PedidoDAO pedidoDAO = new PedidoDAO(entityManager);
		
		entityManager.getTransaction().begin();
		Pedido pedido = new Pedido();
		pedido.setLoginUsuario("brunoabia");
		pedido.setNomeProduto("HOT SPYCE");
		pedido.setNumMesa(6);
		pedido.setQuantidade(1);
		pedido.setStatusPedido(StatusPedidoEnum.PEDIDO_CADASTRADO);
		
		pedidoDAO.cadastrar(pedido);
		entityManager.getTransaction().commit();
		entityManager.close();
	
		Assert.assertNotNull(pedido.getId());
	}

	@Test
	public void testAlterar() {
		fail("Not yet implemented");
	}

	@Test
	public void testExcluir() {
		fail("Not yet implemented");
	}

	@Test
	public void testListar() {
		fail("Not yet implemented");
	}

}
