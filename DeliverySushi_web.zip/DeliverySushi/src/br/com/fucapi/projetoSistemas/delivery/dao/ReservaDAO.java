package br.com.fucapi.projetoSistemas.delivery.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.fucapi.projetoSistemas.delivery.bean.Reserva;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusReservaEnum;



public class ReservaDAO {
	private EntityManager entityManager;

	public ReservaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void cadastrar(Reserva reserva){
		
		entityManager.persist(reserva);
	}
	
	public void alterar(Reserva reserva){
		entityManager.merge(reserva);
	}
	
	public void excluir(Reserva reserva){
		entityManager.remove(reserva);		
	}


	public List<Reserva> listar(StatusReservaEnum statusReserva, int numMesa){
		
		String sql = "Select reserva from Reserva reserva ";
		
		
			if(numMesa != 0){	
				sql = sql + " where  reserva.numMesa = :numMesa and  reserva.statusReservaEnum = :statusReserva";
			}else{
				sql = sql + " where  reserva.statusReservaEnum = :statusReserva";
			}
				
		
		Query query= entityManager.createQuery(sql,Reserva.class);
		
		query.setParameter("statusReserva", statusReserva);
		if(numMesa != 0){	
			query.setParameter("numMesa", numMesa);
		}
		
		return query.getResultList();
	}
}
