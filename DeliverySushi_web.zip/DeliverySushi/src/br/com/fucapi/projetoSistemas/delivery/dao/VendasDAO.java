package br.com.fucapi.projetoSistemas.delivery.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.fucapi.projetoSistemas.delivery.bean.Vendas;

public class VendasDAO {
	
	private EntityManager entityManager;

	public VendasDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void cadastrar(Vendas vendas){
		
		entityManager.persist(vendas);
	}
	
	public void alterar(Vendas vendas){
		entityManager.merge(vendas);
	}
	
	public void excluir(Vendas vendas){
		entityManager.remove(vendas);		
	}
	
	
	public List<Vendas> listar(){
		
		String sql = "Select vendas from Vendas vendas ";
				
		
		Query query= entityManager.createQuery(sql,Vendas.class);
		
		
		return query.getResultList();
	}
	

}
