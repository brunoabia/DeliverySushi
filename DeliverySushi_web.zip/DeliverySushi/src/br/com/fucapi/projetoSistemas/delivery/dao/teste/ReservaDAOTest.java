package br.com.fucapi.projetoSistemas.delivery.dao.teste;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;

import junit.framework.Assert;

import org.junit.Test;

import br.com.fucapi.projetoSistemas.delivery.bean.Reserva;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusReservaEnum;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.ReservaDAO;

public class ReservaDAOTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testCadastrar() {
		EntityManager entityManager = JPAUtil.getEntityManager();
		ReservaDAO reservaDAO = new ReservaDAO(entityManager);
		
		entityManager.getTransaction().begin();
		Reserva reserva = new Reserva();
		
		reserva.setHorario("19:00");
		reserva.setNome("Bruno �bia");
		reserva.setnumMesa(3);
		reserva.setStatusReservaEnum(StatusReservaEnum.RESERVA_CADASTRADA);
		
		reservaDAO.cadastrar(reserva);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		
		Assert.assertNotNull(reserva.getId());
		
	}

	
	@Test
	public void testAlterar() {
		fail("Not yet implemented");
	}

	@Test
	public void testExcluir() {
		fail("Not yet implemented");
	}

	@Test
	public void testListar() {
		fail("Not yet implemented");
	}
}
