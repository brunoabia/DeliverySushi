package br.com.fucapi.projetoSistemas.delivery.dao.teste;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;

import junit.framework.Assert;

import org.junit.Test;

import br.com.fucapi.projetoSistemas.delivery.bean.TipoProdutoEnum;
import br.com.fucapi.projetoSistemas.delivery.bean.Vendas;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.VendasDAO;

public class VendasDAOTest {

	@Test
	public void testVendasDAO() {
		fail("Not yet implemented");
	}

	@Test
	public void testCadastrar() {
		EntityManager entityManager = JPAUtil.getEntityManager();
		VendasDAO vendasDAO = new VendasDAO(entityManager);
		
		entityManager.getTransaction().begin();
		Vendas vendas = new Vendas();
		vendas.setNomeProduto("TEMAKI HOT");
		vendas.setQuantidade(80);
		vendas.setValorUnitario(Float.parseFloat("16.00"));
		vendas.setValorTotal(Float.parseFloat("1280.00"));
		vendas.setTipoProdutoEnum(TipoProdutoEnum.TIPO_TEMAKI);
		
		vendasDAO.cadastrar(vendas);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		Assert.assertNotNull(vendas.getId());
		
		
	}

	@Test
	public void testAlterar() {
		fail("Not yet implemented");
	}

	@Test
	public void testExcluir() {
		fail("Not yet implemented");
	}

	@Test
	public void testListar() {
		fail("Not yet implemented");
	}

}
