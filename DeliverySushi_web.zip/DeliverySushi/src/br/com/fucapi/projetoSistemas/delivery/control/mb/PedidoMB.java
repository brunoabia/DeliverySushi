package br.com.fucapi.projetoSistemas.delivery.control.mb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;

import br.com.fucapi.projetoSistemas.delivery.bean.Pedido;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusPedidoEnum;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.PedidoDAO;

@ViewScoped
@ManagedBean
public class PedidoMB {
	
   private Pedido pedido = new Pedido();
   public List<Pedido> listPedido = new ArrayList<Pedido>();

   
   public Pedido getPedido() {
		return pedido;
	}
	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
	public List<Pedido> getListPedido() {
		return listPedido;
	}
	
	
	public void salvar(){
		EntityManager entityManager = JPAUtil.getEntityManager();
		PedidoDAO pedidoDAO = new PedidoDAO(entityManager);
		
		entityManager.getTransaction().begin();
		//pedidoDAO.alterar(pedido);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		carregarProdutos(pedido.getStatusPedido(), pedido.getNumMesa());
		pedido = new Pedido();
		
	}
   
	@PostConstruct
	public void carregarProdutos(StatusPedidoEnum statusPedido , int numMesa){
		EntityManager em = JPAUtil.getEntityManager();
		PedidoDAO pedidoDAO = new PedidoDAO(em);
		listPedido = pedidoDAO.listar(statusPedido,numMesa);
		em.close();
	}
	
   

}
