package br.com.fucapi.projetoSistemas.delivery.bean;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Reserva {
	
	@Id
	@GeneratedValue
	private Long id;
	private int numMesa;
	private String horario;
	private String nome;
	private StatusReservaEnum statusReservaEnum;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getnumMesa() {
		return numMesa;
	}
	public void setnumMesa(int numMesa) {
		this.numMesa = numMesa;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Enumerated
	public StatusReservaEnum getStatusReservaEnum() {
		return statusReservaEnum;
	}
	public void setStatusReservaEnum(StatusReservaEnum statusReservaEnum) {
		this.statusReservaEnum = statusReservaEnum;
	}
	
	

}
