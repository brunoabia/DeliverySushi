package br.com.fucapi.projetoSistemas.delivery.control.mb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;

import br.com.fucapi.projetoSistemas.delivery.bean.Vendas;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.VendasDAO;


@ViewScoped
@ManagedBean
public class VendasMB {
	private Vendas vendas = new Vendas();
	private List<Vendas> listVendas = new ArrayList<Vendas>();
	
	
	@PostConstruct
	public void listarVendas(){
		EntityManager entityManager = JPAUtil.getEntityManager();
		VendasDAO vendasDAO = new VendasDAO(entityManager);
		listVendas= vendasDAO.listar();
		entityManager.close();
	}
	
	
	public Vendas getVendas() {
		return vendas;
	}
	public void setVendas(Vendas vendas) {
		this.vendas = vendas;
	}
	public List<Vendas> getListVendas() {
		return listVendas;
	}
	public void setListVendas(List<Vendas> listVendas) {
		this.listVendas = listVendas;
	}
	
	
	

}
