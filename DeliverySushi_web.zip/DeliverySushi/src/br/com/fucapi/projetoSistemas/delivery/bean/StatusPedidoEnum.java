package br.com.fucapi.projetoSistemas.delivery.bean;

public enum StatusPedidoEnum {
	/** 
	 * 1 - PEDIDO CADASTRADO
	 */
	PEDIDO_CADASTRADO( 1,"PEDIDO CADASTRADO" ),

	/**
	 * 2 - PEDIDO RECEBIDO
	 */
	PEDIDO_RECEBIDO( 2, "PEDIDO RECEBIDO" ),
	
	/**
	* 3 - PEDIDO ENCERRADO
	*/
	PEDIDO_ENCERRADO( 3, "PEDIDO ENCERRADO" ),
	
	/**
	* 4 - PEDIDO CANCELADO
	*/
	PEDIDO_CANCELADO( 4, "PEDIDO CANCELADO" );


	private Integer key;
	private String name;

	private StatusPedidoEnum(Integer key, String name) {
		this.key = key;
		this.name = name;
	}

	public Integer getKey() {
		return key;
	}

	public void setKey(Integer key) {
		this.key = key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static String getNameFormatado(int key) {
		switch (key) {
		case 1:
			return "Pedido Cadastrado";
		case 2:
			return "Pedido Recebido";
		case 3:
			return "Pedido Encerrado";
		case 4:
			return "Pedido Cancelado";
		
		}
		return "Tipo Desconhecido.";
	}
}
