package br.com.fucapi.projetoSistemas.delivery.control.mb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;

import br.com.fucapi.projetoSistemas.delivery.bean.Pedido;
import br.com.fucapi.projetoSistemas.delivery.bean.Reserva;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusPedidoEnum;
import br.com.fucapi.projetoSistemas.delivery.bean.StatusReservaEnum;
import br.com.fucapi.projetoSistemas.delivery.dao.JPAUtil;
import br.com.fucapi.projetoSistemas.delivery.dao.ReservaDAO;


@ViewScoped
@ManagedBean
public class ReservaMB {

	private Reserva reserva = new Reserva();
	private List<Reserva> listReservas = new ArrayList<Reserva>();
	
	public void salvar(){
		carregarReservas(reserva.getStatusReservaEnum(), reserva.getnumMesa());
		reserva = new Reserva();
		
	}
	
	@PostConstruct
	public void carregarReservas(StatusReservaEnum statusReserva , int numMesa){
		EntityManager em = JPAUtil.getEntityManager();
		ReservaDAO reservaDAO = new ReservaDAO(em);
		listReservas = reservaDAO.listar(statusReserva, numMesa);
		em.close();
	}
	
	public Reserva getReserva() {
		return reserva;
	}
	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}
	public List<Reserva> getListReservas() {
		return listReservas;
	}
	public void setListReservas(List<Reserva> listReservas) {
		this.listReservas = listReservas;
	}
	
	
	
}
