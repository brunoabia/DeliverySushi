package br.com.fucapi.projetoSistemas.delivery.bean;

import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Pedido {
	
	
	@Id
	@GeneratedValue
	private Long id;
	private String nomeProduto;
	private int quantidade;
	private String loginUsuario;
	private int numMesa;
	private StatusPedidoEnum statusPedido;
	
	
	
	@Enumerated
	public StatusPedidoEnum getStatusPedido() {
		return statusPedido;
	}
	public void setStatusPedido(StatusPedidoEnum statusPedido) {
		this.statusPedido = statusPedido;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNomeProduto() {
		return nomeProduto;
	}
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public String getLoginUsuario() {
		return loginUsuario;
	}
	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}
	public int getNumMesa() {
		return numMesa;
	}
	public void setNumMesa(int numMesa) {
		this.numMesa = numMesa;
	}
	
	
	
	
	
	

}
