package br.com.fucapi.projetoSistemas.delivery.bean;

public enum StatusReservaEnum {
	/** 
	 * 1 - RESERVA CADASTRADA
	 */
	RESERVA_CADASTRADA( 0,"RESERVA CADASTRADA" ),
	
	/** 
	 * 2 - RESERVA CADASTRADA
	 */
	RESERVA_CONFIRMADA( 1,"RESERVA CONFIRMADA" ),
	
	/**
	* 3 - RESERVA CANCELADA
	*/
	RESERVA_CANCELADA( 2, "RESERVA CANCELADA" );


	private Integer key;
	private String name;
	
	
	private StatusReservaEnum(Integer key, String name) {
		this.key = key;
		this.name = name;
	}


	public Integer getKey() {
		return key;
	}


	public void setKey(Integer key) {
		this.key = key;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public static String getNameFormatado(int key) {
		switch (key) {
		case 0:
			return "Reserva Cadastrada";
		case 1:
			return "Reserva Confirmada";
		case 2:
			return "Reserva Cancelada";	
		}
		return "Tipo Desconhecido.";
	}
}
